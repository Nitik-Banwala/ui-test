export const DashboardIcon = ({ active }) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <rect x="1" y="1" width="7" height="7" rx="1.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" />
        <rect x="10" y="1" width="7" height="7" rx="1.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" />
        <rect x="1" y="10" width="7" height="7" rx="1.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" />
        <rect x="10" y="10" width="7" height="7" rx="1.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" />
    </svg>
);

export const ThreatIcon = ({ active }) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path d="M9 1L16 5V9C16 13 12.5 16.5 9 17C5.5 16.5 2 13 2 9V5L9 1Z" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinejoin="round" />
        <path d="M9 6V9.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="9" cy="12" r="0.75" fill={active ? "#1A9BFF" : "#687A9B"} />
    </svg>
);

export const RemediationIcon = ({ active }) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path d="M3 9H15" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinecap="round" />
        <path d="M3 4.5H15" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinecap="round" />
        <path d="M3 13.5H10" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinecap="round" />
        <circle cx="14" cy="13.5" r="2.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.3" />
        <path d="M13.2 13.5L13.8 14.1L15 13" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const ComplianceIcon = ({ active }) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <rect x="3" y="1.5" width="12" height="15" rx="1.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" />
        <path d="M6 6H12M6 9H12M6 12H9" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.3" strokeLinecap="round" />
    </svg>
);

export const ReportsIcon = ({ active }) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <path d="M3 14V10M7 14V7M11 14V4M15 14V9" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
);

export const SettingsIcon = ({ active }) => (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
        <circle cx="9" cy="9" r="2.5" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" />
        <path d="M9 1.5V3M9 15V16.5M1.5 9H3M15 9H16.5M3.2 3.2L4.3 4.3M13.7 13.7L14.8 14.8M3.2 14.8L4.3 13.7M13.7 4.3L14.8 3.2" stroke={active ? "#1A9BFF" : "#687A9B"} strokeWidth="1.5" strokeLinecap="round" />
    </svg>
);

export const SearchIcon = () => (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <circle cx="7" cy="7" r="5" stroke="#B0BFCF" strokeWidth="1.5" />
        <path d="M11 11L14 14" stroke="#B0BFCF" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
);

export const MessageIcon = () => (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d="M2 4a2 2 0 012-2h12a2 2 0 012 2v8a2 2 0 01-2 2H6l-4 4V4z" stroke="#687A9B" strokeWidth="1.5" strokeLinejoin="round" />
        <circle cx="14" cy="3" r="3" fill="#F43F5E" />
        <text x="14" y="4.5" textAnchor="middle" fontSize="4" fill="white" fontWeight="bold">2</text>
    </svg>
);

export const NotificationIcon = () => (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path d="M10 2a6 6 0 00-6 6v3l-2 2v1h16v-1l-2-2V8a6 6 0 00-6-6z" stroke="#687A9B" strokeWidth="1.5" strokeLinejoin="round" />
        <path d="M8 16a2 2 0 004 0" stroke="#687A9B" strokeWidth="1.5" />
        <circle cx="15" cy="4" r="3" fill="#1A9BFF" />
        <text x="15" y="5.5" textAnchor="middle" fontSize="4" fill="white" fontWeight="bold">5</text>
    </svg>
);

export const ChevronDownIcon = () => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
        <path d="M2 4L6 8L10 4" stroke="#687A9B" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const LogoIcon = () => (
    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
        <rect width="32" height="32" rx="8" fill="#1A9BFF" />
        <path d="M16 5L26 10V16C26 21.5 21.5 26.5 16 27C10.5 26.5 6 21.5 6 16V10L16 5Z" fill="white" fillOpacity="0.2" />
        <path d="M16 8L23 12V16C23 20 19.5 23.5 16 24C12.5 23.5 9 20 9 16V12L16 8Z" fill="white" fillOpacity="0.3" />
        <circle cx="16" cy="16" r="4" fill="white" />
    </svg>
);

export const CollapseIcon = () => (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M10 3L5 8L10 13" stroke="#687A9B" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);

export const ExpandIcon = () => (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M6 3L11 8L6 13" stroke="#687A9B" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
);
