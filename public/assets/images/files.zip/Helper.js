export const remediationData = [
    {
        action: "Patch Apache server vulnerability on Finance VM",
        threat: "CVE-2023-29324 – Remote code execution",
        sla: "2 days left",
        suggestedBy: "AI Engine",
        status: "Open",
        level: "High",
        date: "Jun 17, 2025 – 11:42 AM",
        ticket: "+ Create Ticket",
        isLight: true,
    },
    {
        action: "Restrict public RDP access on HR server",
        threat: "Lateral movement risk via RDP",
        sla: "Overdue",
        suggestedBy: "AI Engine ",
        status: "Open",
        level: "Medium",
        date: "Jun 16, 2025 – 03:22 PM",
        ticket: "View in JIRA",
        isLight: false,
    },
    {
        action: "Rotate AWS IAM credentials",
        threat: "Compromised credential usage detected",
        sla: "2 days left",
        suggestedBy: "Security Analyst",
        status: "In Progress",
        level: "Low",
        date: "Jun 15, 2025 – 10:10 AM",
        ticket: "View in JIRA",
        isLight: true,
    },
    {
        action: "Disable legacy TLS 1.0 support",
        threat: "TLS downgrade vulnerability",
        sla: "Overdue",
        suggestedBy: "AI Engine",
        status: "Open",
        level: "High",
        date: "Jun 15, 2025 – 04:45 PM",
        ticket: "+ Create Ticket",
        isLight: false,
    },
    {
        action: "Patch outdated version of Microsoft Exchange",
        threat: "CVE-2024-21006 – Elevation of privilege",
        sla: "2 days left",
        suggestedBy: "Security Analyst",
        status: "In Progress",
        level: "Medium",
        date: "Jun 14, 2025 – 02:18 PM",
        ticket: "View in JIRA",
        isLight: true,
    },
    {
        action: "Revoke stale admin access on DevOps accounts",
        threat: "Unused privileged accounts",
        sla: "Overdue",
        suggestedBy: "AI Engine ",
        status: "Resolved",
        level: "Low",
        date: "Jun 13, 2025 – 01:55 PM",
        ticket: "View in JIRA",
        isLight: false,
    },
    {
        action: "Quarantine endpoint with malware beaconing",
        threat: "Detected communication with C2 server",
        sla: "2 days left",
        suggestedBy: "AI Engine",
        status: "Open",
        level: "High",
        date: "Jun 12, 2025 – 05:08 PM",
        ticket: "+ Create Ticket",
        isLight: true,
    },
];

export const SELECT_LIST = [
    { select: "Status",         key: "status",     option: ["Open", "In Progress", "Resolved"] },
    { select: "Assigned To",    key: "assignedTo", option: ["AI Engine", "Security Analyst"] },
    { select: "Threat Level",   key: "level",      option: ["High", "Medium", "Low"] },
    { select: "Deadline Range", key: "deadline",   option: ["Overdue", "2 days left"] },
];

export const SUGGESTIONS = [
    "Patch Apache server vulnerability",
    "Restrict public RDP access",
    "Rotate AWS IAM credentials",
    "Disable legacy TLS 1.0 support",
    "Patch Microsoft Exchange",
    "Revoke stale admin access",
    "Quarantine endpoint malware",
    "CVE-2023-29324",
    "CVE-2024-21006",
    "Remote code execution",
];

export const ITEMS_PER_PAGE = 7;

export const NAV_ITEMS = [
    { label: "Dashboard",            icon: "dashboard" },
    { label: "Threat Intelligence",  icon: "threat" },
    { label: "Remediation Tracker",  icon: "remediation", active: true },
    { label: "Compliance",           icon: "compliance" },
    { label: "Reports",              icon: "reports" },
    { label: "Settings",             icon: "settings" },
];

export const STAT_CARDS = [
    { label: "Total Actions",    value: "16",  sub: "+3 this week",   color: "#1A9BFF", bg: "#EBF5FF" },
    { label: "Open",             value: "7",   sub: "Needs attention", color: "#F43F5E", bg: "#FFF1F3" },
    { label: "In Progress",      value: "5",   sub: "Being worked on", color: "#F59E0B", bg: "#FFFBEB" },
    { label: "Resolved",         value: "4",   sub: "Completed",       color: "#10B981", bg: "#ECFDF5" },
];
