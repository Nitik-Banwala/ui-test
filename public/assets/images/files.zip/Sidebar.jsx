import { useState } from "react";
import { NAV_ITEMS } from "../../utils/Helper";
import {
    LogoIcon, CollapseIcon, ExpandIcon,
    DashboardIcon, ThreatIcon, RemediationIcon,
    ComplianceIcon, ReportsIcon, SettingsIcon,
} from "../common/Icons";

const iconMap = {
    dashboard:   DashboardIcon,
    threat:      ThreatIcon,
    remediation: RemediationIcon,
    compliance:  ComplianceIcon,
    reports:     ReportsIcon,
    settings:    SettingsIcon,
};

const Sidebar = ({ activeNav, setActiveNav, onCollapse }) => {
    const [collapsed, setCollapsed] = useState(false);

    const handleCollapse = () => {
        const next = !collapsed;
        setCollapsed(next);
        onCollapse?.(next);
    };

    const mainItems = NAV_ITEMS.filter(i => i.icon !== "settings");
    const settingItem = NAV_ITEMS.find(i => i.icon === "settings");

    return (
        <aside
            className={`fixed left-0 top-0 h-screen bg-white border-r border-[#E6EFFB] flex flex-col transition-all duration-300 z-20 ${collapsed ? "w-18" : "w-60"}`}
        >
            {/* Logo */}
            <div className={`flex items-center gap-3 px-5 py-5 border-b border-[#E6EFFB] ${collapsed ? "justify-center px-3" : ""}`}>
                <div className="flex-shrink-0">
                    <LogoIcon />
                </div>
                {!collapsed && (
                    <div>
                        <p className="text-[14px] font-bold text-[#0B0C1A] leading-tight">ThreatQuantum</p>
                        <p className="text-[10px] text-[#687A9B] font-medium tracking-wider uppercase">AI Security</p>
                    </div>
                )}
            </div>

            {/* Nav items */}
            <nav className="flex-1 py-4 flex flex-col gap-1 px-3 overflow-y-auto">
                {!collapsed && (
                    <p className="text-[10px] font-semibold text-[#B0BFCF] uppercase tracking-widest px-3 mb-2">
                        Main Menu
                    </p>
                )}

                {mainItems.map((item) => {
                    const Icon = iconMap[item.icon];
                    const isActive = activeNav === item.label;
                    return (
                        <button
                            key={item.label}
                            onClick={() => setActiveNav(item.label)}
                            title={collapsed ? item.label : ""}
                            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl w-full text-left transition-all duration-150 group relative
                                ${isActive
                                    ? "bg-[#EBF5FF] text-[#1A9BFF]"
                                    : "text-[#687A9B] hover:bg-[#F5F8FF] hover:text-[#2D4453]"
                                } ${collapsed ? "justify-center" : ""}`}
                        >
                            {isActive && (
                                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#1A9BFF] rounded-r-full" />
                            )}
                            <span className="flex-shrink-0">
                                <Icon active={isActive} />
                            </span>
                            {!collapsed && (
                                <span className={`text-[13px] font-medium ${isActive ? "text-[#1A9BFF]" : ""}`}>
                                    {item.label}
                                </span>
                            )}

                            {/* Tooltip on collapsed */}
                            {collapsed && (
                                <span className="absolute left-full ml-3 bg-[#0B0C1A] text-white text-[12px] px-2.5 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap transition-opacity z-50">
                                    {item.label}
                                </span>
                            )}
                        </button>
                    );
                })}
            </nav>

            {/* Bottom: Settings + User + Collapse */}
            <div className="border-t border-[#E6EFFB] py-4 px-3 flex flex-col gap-1">
                {/* Settings */}
                {settingItem && (() => {
                    const Icon = iconMap[settingItem.icon];
                    const isActive = activeNav === settingItem.label;
                    return (
                        <button
                            onClick={() => setActiveNav(settingItem.label)}
                            title={collapsed ? settingItem.label : ""}
                            className={`flex items-center gap-3 px-3 py-2.5 rounded-xl w-full text-left transition-all group relative
                                ${isActive ? "bg-[#EBF5FF] text-[#1A9BFF]" : "text-[#687A9B] hover:bg-[#F5F8FF]"}
                                ${collapsed ? "justify-center" : ""}`}
                        >
                            {isActive && <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-[#1A9BFF] rounded-r-full" />}
                            <Icon active={isActive} />
                            {!collapsed && <span className="text-[13px] font-medium">{settingItem.label}</span>}
                            {collapsed && (
                                <span className="absolute left-full ml-3 bg-[#0B0C1A] text-white text-[12px] px-2.5 py-1.5 rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap transition-opacity z-50">
                                    {settingItem.label}
                                </span>
                            )}
                        </button>
                    );
                })()}

                {/* User card */}
                <div className={`flex items-center gap-3 px-3 py-2.5 mt-1 rounded-xl bg-[#F5F8FF] ${collapsed ? "justify-center" : ""}`}>
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1A9BFF] to-[#0070D8] flex items-center justify-center text-white text-[12px] font-bold flex-shrink-0">
                        JD
                    </div>
                    {!collapsed && (
                        <div className="min-w-0">
                            <p className="text-[12px] font-semibold text-[#2D4453] truncate">John Doe</p>
                            <p className="text-[10px] text-[#687A9B] truncate">Security Analyst</p>
                        </div>
                    )}
                </div>

                {/* Collapse toggle */}
                <button
                    onClick={handleCollapse}
                    className={`flex items-center gap-2 px-3 py-2 mt-1 rounded-xl text-[#687A9B] hover:bg-[#F5F8FF] hover:text-[#2D4453] transition-all w-full ${collapsed ? "justify-center" : ""}`}
                >
                    {collapsed ? <ExpandIcon /> : <CollapseIcon />}
                    {!collapsed && <span className="text-[12px] font-medium">Collapse</span>}
                </button>
            </div>
        </aside>
    );
};

export default Sidebar;
