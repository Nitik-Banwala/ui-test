import { useState, useRef, useEffect } from "react";
import { SUGGESTIONS } from "../../utils/Helper";
import { SearchIcon, MessageIcon, NotificationIcon } from "../common/Icons";

const Navbar = ({ search, setSearch, sidebarCollapsed }) => {
    const [focused, setFocused]             = useState(false);
    const [showSuggestions, setShowSuggestions] = useState(false);
    const inputRef  = useRef(null);
    const wrapperRef = useRef(null);

    const filteredSuggestions = search.length > 0
        ? SUGGESTIONS.filter(s => s.toLowerCase().includes(search.toLowerCase()))
        : [];

    useEffect(() => {
        const handler = (e) => {
            if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
                setShowSuggestions(false);
                setFocused(false);
            }
        };
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, []);

    const mlClass = sidebarCollapsed ? "ml-18" : "ml-60";

    return (
        <header
            className={`fixed top-0 right-0 h-16 bg-white border-b border-[#E6EFFB] flex items-center justify-between px-6 z-10 transition-all duration-300 ${mlClass}`}
            style={{ left: sidebarCollapsed ? "4.5rem" : "15rem" }}
        >
            {/* Page breadcrumb */}
            <div className="hidden sm:flex flex-col">
                <h2 className="text-[15px] font-bold text-[#0B0C1A]">Remediation Tracker</h2>
                <p className="text-[11px] text-[#687A9B]">Dashboard / Remediation Tracker</p>
            </div>

            {/* Search */}
            <div ref={wrapperRef} className="relative">
                <div
                    className={`flex items-center bg-[#F5F8FF] rounded-xl h-9 transition-all duration-200 ${focused ? "ring-2 ring-[#1A9BFF]/30 bg-white shadow-sm" : ""}`}
                    style={{ width: focused ? 300 : 220 }}
                >
                    <div className="pl-3 flex-shrink-0">
                        <SearchIcon />
                    </div>
                    <input
                        ref={inputRef}
                        type="text"
                        placeholder="Search actions, threats…"
                        value={search}
                        onChange={e => { setSearch(e.target.value); setShowSuggestions(true); }}
                        onFocus={() => { setFocused(true); if (search.length > 0) setShowSuggestions(true); }}
                        className="flex-1 px-3 text-[13px] text-[#2D4453] outline-none bg-transparent placeholder:text-[#B0BFCF]"
                    />
                    {search && (
                        <button
                            onClick={() => { setSearch(""); inputRef.current?.focus(); }}
                            className="pr-3 text-[#B0BFCF] hover:text-[#687A9B] transition-colors"
                        >
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                                <path d="M9 3L3 9M3 3L9 9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                            </svg>
                        </button>
                    )}
                </div>

                {/* Suggestions */}
                {showSuggestions && filteredSuggestions.length > 0 && (
                    <div
                        className="absolute top-11 left-0 right-0 bg-white rounded-xl shadow-xl border border-[#E6EFFB] py-1.5 z-50"
                        style={{ animation: "fadeSlide 0.15s ease-out", minWidth: 260 }}
                    >
                        <p className="px-4 py-1 text-[10px] font-bold text-[#B0BFCF] uppercase tracking-widest">
                            Suggestions
                        </p>
                        {filteredSuggestions.map((s, i) => (
                            <button
                                key={i}
                                onClick={() => { setSearch(s); setShowSuggestions(false); }}
                                className="w-full text-left px-4 py-2 text-[13px] text-[#2D4453] hover:bg-[#F3F6FC] flex items-center gap-2.5 transition-colors"
                            >
                                <SearchIcon />
                                <span
                                    dangerouslySetInnerHTML={{
                                        __html: s.replace(
                                            new RegExp(`(${search})`, "gi"),
                                            '<mark style="background:#EBF5FF;color:#1A9BFF;border-radius:3px;padding:0 2px;">$1</mark>'
                                        ),
                                    }}
                                />
                            </button>
                        ))}
                    </div>
                )}

                {showSuggestions && search.length > 0 && filteredSuggestions.length === 0 && (
                    <div className="absolute top-11 left-0 bg-white rounded-xl shadow-xl border border-[#E6EFFB] px-4 py-3 z-50 whitespace-nowrap">
                        <p className="text-[13px] text-[#B0BFCF]">
                            No results for "<span className="text-[#687A9B]">{search}</span>"
                        </p>
                    </div>
                )}
            </div>

            {/* Right actions */}
            <div className="flex items-center gap-5">
                <button className="relative hover:opacity-75 transition-opacity">
                    <MessageIcon />
                </button>
                <button className="relative hover:opacity-75 transition-opacity">
                    <NotificationIcon />
                </button>
                <div className="flex items-center gap-2.5 pl-3 border-l border-[#E6EFFB]">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#1A9BFF] to-[#0070D8] flex items-center justify-center text-white text-[12px] font-bold">
                        JD
                    </div>
                    <div className="hidden md:block">
                        <p className="text-[12px] font-semibold text-[#2D4453] leading-tight">John Doe</p>
                        <p className="text-[10px] text-[#687A9B]">Security Analyst</p>
                    </div>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" className="text-[#B0BFCF]">
                        <path d="M2 4L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                </div>
            </div>
        </header>
    );
};

export default Navbar;
