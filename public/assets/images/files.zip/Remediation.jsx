import { useState, useRef, useEffect, useMemo } from "react";
import { remediationData, SELECT_LIST, ITEMS_PER_PAGE } from "../../utils/Helper";
import { ChevronDownIcon } from "../common/Icons";
import StatCards from "./StatCards";

const Remediation = ({ search }) => {
    const [filters, setFilters]         = useState({ status: "", assignedTo: "", level: "", deadline: "" });
    const [openDropdown, setOpenDropdown] = useState(null);
    const [page, setPage]               = useState(1);
    const dropdownRef                   = useRef(null);

    useEffect(() => {
        const handler = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target))
                setOpenDropdown(null);
        };
        document.addEventListener("mousedown", handler);
        return () => document.removeEventListener("mousedown", handler);
    }, []);

    useEffect(() => { setPage(1); }, [search, filters]);

    const filtered = useMemo(() => {
        let d = [...remediationData];
        if (search)           d = d.filter(r => r.action.toLowerCase().includes(search.toLowerCase()) || r.threat.toLowerCase().includes(search.toLowerCase()));
        if (filters.status)   d = d.filter(r => r.status === filters.status);
        if (filters.level)    d = d.filter(r => r.level === filters.level);
        if (filters.assignedTo) d = d.filter(r => r.suggestedBy.trim() === filters.assignedTo);
        if (filters.deadline) d = d.filter(r => r.sla === filters.deadline);
        return d;
    }, [search, filters]);

    const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
    const paginated  = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

    const anyActive = Object.values(filters).some(Boolean);

    return (
        <div>
            {/* Page title */}
            <div className="mb-6">
                <h1 className="text-[22px] font-bold text-[#0B0C1A]">Remediation Tracker</h1>
                <p className="text-[13px] text-[#687A9B] mt-1">
                    Track, manage, and resolve security vulnerabilities across your infrastructure.
                </p>
            </div>

            {/* Stat cards */}
            <StatCards />

            {/* Filters row */}
            <div
                ref={dropdownRef}
                className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-5"
            >
                {SELECT_LIST.map((item, index) => {
                    const activeVal = filters[item.key];
                    const isOpen    = openDropdown === item.select;

                    return (
                        <div key={index} className="relative">
                            <button
                                onClick={() => setOpenDropdown(isOpen ? null : item.select)}
                                className={`w-full h-11 flex items-center justify-between px-4 rounded-2xl border text-[13px] font-medium transition-all
                                    ${activeVal
                                        ? "bg-[#EBF5FF] border-[#1A9BFF] text-[#1A9BFF]"
                                        : "bg-white border-[#E6EFFB] text-[#687A9B] hover:border-[#1A9BFF]/30 hover:text-[#2D4453]"
                                    }`}
                            >
                                <span>{activeVal || item.select}</span>
                                <span className={`transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`}>
                                    <ChevronDownIcon />
                                </span>
                            </button>

                            {isOpen && (
                                <div
                                    className="absolute top-12 left-0 right-0 bg-white border border-[#E6EFFB] rounded-2xl shadow-lg z-50 py-2 overflow-hidden"
                                    style={{ animation: "fadeSlide 0.15s ease-out" }}
                                >
                                    {activeVal && (
                                        <button
                                            onClick={() => { setFilters(f => ({ ...f, [item.key]: "" })); setOpenDropdown(null); }}
                                            className="w-full text-left px-4 py-2 text-[12px] text-[#B0BFCF] hover:bg-[#F3F6FC] flex items-center gap-2"
                                        >
                                            <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                                                <path d="M8 2L2 8M2 2L8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                            </svg>
                                            Clear filter
                                        </button>
                                    )}
                                    {item.option.map((op, idx) => (
                                        <button
                                            key={idx}
                                            onClick={() => { setFilters(f => ({ ...f, [item.key]: op })); setOpenDropdown(null); }}
                                            className={`w-full text-left px-4 py-2.5 text-[13px] transition-colors
                                                ${activeVal === op
                                                    ? "bg-[#F0F7FF] text-[#1A9BFF] font-semibold"
                                                    : "text-[#2D4453] hover:bg-[#F3F6FC]"
                                                }`}
                                        >
                                            {op}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            {/* Active filter chips */}
            {anyActive && (
                <div className="flex flex-wrap items-center gap-2 mb-4">
                    <span className="text-[12px] text-[#687A9B]">Active filters:</span>
                    {Object.entries(filters).map(([key, val]) => {
                        if (!val) return null;
                        const label = SELECT_LIST.find(s => s.key === key)?.select || key;
                        return (
                            <span key={key} className="flex items-center gap-1.5 bg-[#EBF5FF] text-[#1A9BFF] text-[12px] font-medium px-2.5 py-1 rounded-full">
                                {label}: {val}
                                <button onClick={() => setFilters(f => ({ ...f, [key]: "" }))} className="hover:text-blue-700">
                                    <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
                                        <path d="M8 2L2 8M2 2L8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
                                    </svg>
                                </button>
                            </span>
                        );
                    })}
                    <button
                        onClick={() => setFilters({ status: "", assignedTo: "", level: "", deadline: "" })}
                        className="text-[12px] text-[#687A9B] hover:text-red-500 underline transition-colors"
                    >
                        Clear all
                    </button>
                </div>
            )}

            {/* Table card */}
            <div className="bg-white rounded-2xl border border-[#E6EFFB] overflow-hidden">
                {/* Table header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-[#F0F4FC]">
                    <h2 className="text-[15px] font-semibold text-[#0B0C1A]">Remediation Actions</h2>
                    <div className="flex items-center gap-3">
                        {search && (
                            <span className="text-[12px] text-[#687A9B] bg-[#F3F6FC] px-3 py-1 rounded-full">
                                "{search}" · {filtered.length} result{filtered.length !== 1 ? "s" : ""}
                            </span>
                        )}
                        <span className="text-[12px] text-[#687A9B] bg-[#F3F6FC] px-3 py-1 rounded-full">
                            {filtered.length} item{filtered.length !== 1 ? "s" : ""}
                        </span>
                    </div>
                </div>

                {/* Scrollable table */}
                <div className="overflow-x-auto">
                    <table className="w-full text-sm border-separate border-spacing-y-0">
                        <thead>
                            <tr className="bg-[#F8FAFD]">
                                {["Action", "Associated Threat", "SLA Due In", "Suggested By", "Status", "Threat Level", "Created On", "Ticket"].map((th) => (
                                    <th
                                        key={th}
                                        className="px-5 py-3 text-left text-[11px] font-bold text-[#687A9B] uppercase tracking-widest border-b border-[#E6EFFB] whitespace-nowrap"
                                    >
                                        {th}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {paginated.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="text-center py-16">
                                        <div className="flex flex-col items-center gap-2">
                                            <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
                                                <circle cx="20" cy="20" r="18" stroke="#E6EFFB" strokeWidth="2" />
                                                <path d="M14 20h12M20 14v12" stroke="#B0BFCF" strokeWidth="2" strokeLinecap="round" />
                                            </svg>
                                            <p className="text-[13px] text-[#B0BFCF]">No results match your filters.</p>
                                        </div>
                                    </td>
                                </tr>
                            ) : (
                                paginated.map((item, index) => (
                                    <tr
                                        key={index}
                                        className={`group hover:bg-[#F8FAFD] transition-colors border-b border-[#F0F4FC] last:border-0
                                            ${item.isLight ? "bg-[#FAFBFF]" : "bg-white"}`}
                                        style={{ animation: `rowIn 0.2s ease-out ${index * 40}ms both` }}
                                    >
                                        {/* Action */}
                                        <td className="px-5 py-3.5 max-w-[210px]">
                                            <span className="text-[13px] text-[#2D4453] font-medium leading-snug line-clamp-2">
                                                {item.action}
                                            </span>
                                        </td>

                                        {/* Threat */}
                                        <td className="px-5 py-3.5 max-w-[180px]">
                                            <span className="text-[12px] text-[#687A9B] leading-snug line-clamp-2">
                                                {item.threat}
                                            </span>
                                        </td>

                                        {/* SLA */}
                                        <td className="px-5 py-3.5 whitespace-nowrap">
                                            <span className={`text-[12px] font-semibold px-2.5 py-1 rounded-lg ${item.sla === "Overdue" ? "bg-red-50 text-red-500" : "bg-blue-50 text-blue-500"}`}>
                                                {item.sla}
                                            </span>
                                        </td>

                                        {/* Suggested By */}
                                        <td className="px-5 py-3.5 whitespace-nowrap">
                                            <span className="flex items-center gap-2 text-[13px] text-[#2D4453]">
                                                <span className={`h-2 w-2 rounded-full flex-shrink-0 ${item.suggestedBy.trim() === "Security Analyst" ? "bg-[#1A9BFF]" : "bg-[#FFD800]"}`} />
                                                {item.suggestedBy.trim()}
                                            </span>
                                        </td>

                                        {/* Status */}
                                        <td className="px-5 py-3.5 whitespace-nowrap">
                                            <span className={`text-[12px] font-semibold px-2.5 py-1 rounded-lg border
                                                ${item.status === "Open"        ? "bg-blue-50   text-blue-600   border-blue-100"
                                                : item.status === "In Progress" ? "bg-amber-50  text-amber-600  border-amber-100"
                                                :                                  "bg-emerald-50 text-emerald-600 border-emerald-100"}`}
                                            >
                                                {item.status}
                                            </span>
                                        </td>

                                        {/* Threat Level */}
                                        <td className="px-5 py-3.5 whitespace-nowrap">
                                            <span className={`flex items-center gap-1.5 text-[12px] font-semibold px-2.5 py-1 rounded-lg border w-fit
                                                ${item.level === "High"   ? "bg-red-50    text-red-600    border-red-100"
                                                : item.level === "Medium" ? "bg-orange-50 text-orange-500 border-orange-100"
                                                :                           "bg-emerald-50 text-emerald-600 border-emerald-100"}`}
                                            >
                                                <span className={`h-1.5 w-1.5 rounded-full ${item.level === "High" ? "bg-red-500" : item.level === "Medium" ? "bg-orange-400" : "bg-emerald-500"}`} />
                                                {item.level}
                                            </span>
                                        </td>

                                        {/* Date */}
                                        <td className="px-5 py-3.5 whitespace-nowrap text-[12px] text-[#687A9B]">
                                            {item.date}
                                        </td>

                                        {/* Ticket */}
                                        <td className="px-5 py-3.5 whitespace-nowrap">
                                            <button
                                                className={`text-[12px] font-medium transition-all
                                                    ${item.ticket === "+ Create Ticket"
                                                        ? "bg-[#1A9BFF] text-white px-3 py-1.5 rounded-lg hover:bg-[#0080E8] shadow-sm"
                                                        : "text-[#1A9BFF] hover:underline"
                                                    }`}
                                            >
                                                {item.ticket}
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                    <div className="flex items-center justify-between px-6 py-4 border-t border-[#F0F4FC]">
                        <p className="text-[12px] text-[#687A9B]">
                            Showing {(page - 1) * ITEMS_PER_PAGE + 1}–{Math.min(page * ITEMS_PER_PAGE, filtered.length)} of {filtered.length}
                        </p>
                        <div className="flex items-center gap-1">
                            <button
                                onClick={() => setPage(p => Math.max(1, p - 1))}
                                disabled={page === 1}
                                className="h-8 px-3 rounded-lg text-[12px] font-medium text-[#687A9B] hover:bg-[#F3F6FC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                            >
                                Prev
                            </button>
                            {Array.from({ length: totalPages }, (_, i) => i + 1).map(n => (
                                <button
                                    key={n}
                                    onClick={() => setPage(n)}
                                    className={`w-8 h-8 rounded-lg text-[12px] font-medium transition-colors
                                        ${n === page ? "bg-[#1A9BFF] text-white" : "text-[#687A9B] hover:bg-[#F3F6FC]"}`}
                                >
                                    {n}
                                </button>
                            ))}
                            <button
                                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                disabled={page === totalPages}
                                className="h-8 px-3 rounded-lg text-[12px] font-medium text-[#687A9B] hover:bg-[#F3F6FC] disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                            >
                                Next
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Remediation;
