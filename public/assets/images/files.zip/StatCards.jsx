import { STAT_CARDS } from "../../utils/Helper";

const StatCards = () => (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {STAT_CARDS.map((card, i) => (
            <div
                key={i}
                className="bg-white rounded-2xl border border-[#E6EFFB] p-5 flex items-center gap-4 hover:shadow-md transition-shadow"
                style={{ animation: `fadeSlide 0.3s ease-out ${i * 60}ms both` }}
            >
                <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: card.bg }}
                >
                    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
                        <circle cx="11" cy="11" r="8" stroke={card.color} strokeWidth="2" strokeDasharray="4 2" />
                        <circle cx="11" cy="11" r="3" fill={card.color} />
                    </svg>
                </div>
                <div>
                    <p className="text-[24px] font-bold text-[#0B0C1A] leading-tight">{card.value}</p>
                    <p className="text-[12px] font-semibold text-[#2D4453]">{card.label}</p>
                    <p className="text-[11px] text-[#687A9B] mt-0.5">{card.sub}</p>
                </div>
            </div>
        ))}
    </div>
);

export default StatCards;
