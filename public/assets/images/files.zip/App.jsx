import { useState } from "react";
import Sidebar from "./components/Sidebar/Sidebar";
import Navbar from "./components/Navbar/Navbar";
import Remediation from "./components/Remediation/Remediation";

const App = () => {
    const [search, setSearch]       = useState("");
    const [activeNav, setActiveNav] = useState("Remediation Tracker");
    const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

    // Derive collapsed from Sidebar's internal toggle — we pass a callback
    const sidebarWidth = sidebarCollapsed ? "4.5rem" : "15rem";

    return (
        <div className="min-h-screen bg-[#F5F7FB] flex">
            <style>{`
                @import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;0,9..40,700;1,9..40,400&display=swap');
                * { font-family: 'DM Sans', sans-serif; box-sizing: border-box; }
                @keyframes fadeSlide {
                    from { opacity: 0; transform: translateY(-6px); }
                    to   { opacity: 1; transform: translateY(0);    }
                }
                @keyframes rowIn {
                    from { opacity: 0; transform: translateX(-5px); }
                    to   { opacity: 1; transform: translateX(0);    }
                }
                ::-webkit-scrollbar { width: 5px; height: 5px; }
                ::-webkit-scrollbar-track { background: #F5F7FB; }
                ::-webkit-scrollbar-thumb { background: #D1DDEF; border-radius: 10px; }
            `}</style>

            {/* Sidebar */}
            <Sidebar
                activeNav={activeNav}
                setActiveNav={setActiveNav}
                onCollapse={setSidebarCollapsed}
            />

            {/* Main content area */}
            <div
                className="flex-1 flex flex-col min-h-screen transition-all duration-300"
                style={{ marginLeft: sidebarWidth }}
            >
                {/* Navbar */}
                <Navbar
                    search={search}
                    setSearch={setSearch}
                    sidebarCollapsed={sidebarCollapsed}
                />

                {/* Page content */}
                <main className="flex-1 mt-16 p-6">
                    {activeNav === "Remediation Tracker" && (
                        <Remediation search={search} />
                    )}
                    {activeNav !== "Remediation Tracker" && (
                        <div className="flex items-center justify-center h-full min-h-[60vh]">
                            <div className="text-center">
                                <div className="w-16 h-16 bg-[#EBF5FF] rounded-2xl flex items-center justify-center mx-auto mb-4">
                                    <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                                        <rect x="4" y="4" width="20" height="20" rx="4" stroke="#1A9BFF" strokeWidth="2" strokeDasharray="4 2"/>
                                        <path d="M14 10v8M10 14h8" stroke="#1A9BFF" strokeWidth="2" strokeLinecap="round"/>
                                    </svg>
                                </div>
                                <h3 className="text-[16px] font-semibold text-[#2D4453] mb-1">{activeNav}</h3>
                                <p className="text-[13px] text-[#B0BFCF]">This page is under construction</p>
                            </div>
                        </div>
                    )}
                </main>
            </div>
        </div>
    );
};

export default App;
